#!/bin/bash

# Genevieve Mortensen 09/15/2022
# script containing symlinks

#ln -s /home/gamorten/prj/pergnant/trim /home/gamorten/prj/pergnant/GRCh38_noalt_as


ln -s /home/gamorten/bin/FastQC/fastqc /usr/bin/fastqc
