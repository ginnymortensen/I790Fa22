#Created by Genevieve Mortensen for Microbiome research pipeline
#	Stores tool specific variables

TRIM=/N/project/MicrobiomeHealth/anaconda3/bin/trimmomatic
BOWTIE2=/N/project/MicrobiomeHealth/anaconda3/bin/bowtie2
SAM=/N/project/MicrobiomeHealth/pregnant/bin/bin/samtools
FASTQC=/home/gamorten/bin/FastQC/fastqc
